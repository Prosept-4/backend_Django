# -------------------------
#     Users константы
# -------------------------

EMAIL_LENGTH: int = 254
NAME_LENGTH: int = 150
ROLE_LENGTH: int = 20
